import { contextBridge, ipcRenderer } from 'electron'

contextBridge.exposeInMainWorld('odyssey', {
  updater: {
    start: (payload) => ipcRenderer.invoke('updater:start', payload),
    install: (filePath) => ipcRenderer.invoke('updater:install', filePath),
    onProgress: (callback) => {
      const listener = (_event, data) => callback(data)
      ipcRenderer.on('updater:progress', listener)
      return () => ipcRenderer.removeListener('updater:progress', listener)
    },
  },
})
