import { createServer } from 'node:http'
import { createWriteStream, existsSync } from 'node:fs'
import { mkdir, readFile, rename, rm } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFile, spawn } from 'node:child_process'
import { app, BrowserWindow, ipcMain, shell } from 'electron'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const packagedDistDir = path.join(__dirname, '..', 'dist')
const UPDATE_MAX_BYTES = 25 * 1024 * 1024

const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.json': 'application/json',
  '.woff2': 'font/woff2',
}

const allowedDownloadHosts = [
  'github.com',
  'objects.githubusercontent.com',
  'github-releases.githubusercontent.com',
  'release-assets.githubusercontent.com',
]

function overlayRoot() {
  return path.join(app.getPath('userData'), 'updates', 'current')
}

function resolveDistDir() {
  const overlay = path.join(overlayRoot(), 'dist')
  if (existsSync(path.join(overlay, 'index.html'))) return overlay
  if (existsSync(path.join(overlayRoot(), 'index.html'))) return overlayRoot()
  return packagedDistDir
}

function startStaticServer(distDir) {
  return new Promise((resolve, reject) => {
    const server = createServer(async (req, res) => {
      const url = new URL(req.url || '/', 'http://127.0.0.1')
      let filePath = path.normalize(path.join(distDir, decodeURIComponent(url.pathname)))
      if (!filePath.startsWith(distDir)) {
        res.writeHead(403)
        res.end()
        return
      }
      if (url.pathname === '/' || !path.extname(filePath)) {
        filePath = path.join(distDir, 'index.html')
      }
      try {
        const body = await readFile(filePath)
        res.writeHead(200, { 'Content-Type': mimeTypes[path.extname(filePath)] || 'application/octet-stream' })
        res.end(body)
      } catch {
        const fallback = await readFile(path.join(distDir, 'index.html'))
        res.writeHead(200, { 'Content-Type': mimeTypes['.html'] })
        res.end(fallback)
      }
    })

    server.on('error', reject)
    server.listen(0, '127.0.0.1', () => {
      const address = server.address()
      resolve(`http://127.0.0.1:${address.port}`)
    })
  })
}

function hostAllowed(hostname) {
  return allowedDownloadHosts.some((host) => hostname === host || hostname.endsWith(`.${host}`))
}

function safeFileName(name) {
  const base = path.basename(String(name || 'Odyssey Network update.zip'))
  return base.replace(/[^\w.\- ()áéíóöőúüűÁÉÍÓÖŐÚÜŰ]+/g, '_') || 'Odyssey Network update.zip'
}

function extractZip(zipPath, dest) {
  return new Promise((resolve, reject) => {
    execFile('tar', ['-xf', zipPath, '-C', dest], (error) => {
      if (error) reject(error)
      else resolve()
    })
  })
}

async function downloadUpdate(url, dest, onProgress) {
  const response = await fetch(url, {
    headers: {
      Accept: 'application/octet-stream',
      'User-Agent': 'Odyssey-Network-Launcher',
    },
    redirect: 'follow',
  })

  if (!response.ok || !response.body) {
    throw new Error(`Letöltés sikertelen (${response.status}).`)
  }

  const declared = Number(response.headers.get('content-length')) || 0
  if (declared > UPDATE_MAX_BYTES) {
    throw new Error('A frissítőcsomag nagyobb, mint 25 MB.')
  }

  const file = createWriteStream(dest)
  const reader = response.body.getReader()
  let received = 0

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      received += value.byteLength
      if (received > UPDATE_MAX_BYTES) {
        throw new Error('A frissítőcsomag nagyobb, mint 25 MB.')
      }
      if (!file.write(Buffer.from(value))) {
        await new Promise((resolve) => file.once('drain', resolve))
      }
      onProgress(received, declared)
    }
  } catch (error) {
    file.destroy()
    throw error
  }

  await new Promise((resolve, reject) => {
    file.end((endError) => {
      if (endError) reject(endError)
      else resolve()
    })
  })
}

async function installZipUpdate(zipPath) {
  const updatesRoot = path.join(app.getPath('userData'), 'updates')
  const pending = path.join(updatesRoot, 'pending')
  const current = overlayRoot()
  await rm(pending, { recursive: true, force: true })
  await mkdir(pending, { recursive: true })
  await extractZip(zipPath, pending)
  const hasUi =
    existsSync(path.join(pending, 'dist', 'index.html')) || existsSync(path.join(pending, 'index.html'))
  if (!hasUi) {
    throw new Error('A frissítőcsomagban nincs launcher felület (dist).')
  }
  await rm(current, { recursive: true, force: true })
  await mkdir(path.dirname(current), { recursive: true })
  await rename(pending, current)
  app.relaunch()
  app.exit(0)
}

function registerUpdaterIpc() {
  ipcMain.handle('updater:start', async (event, payload) => {
    const url = new URL(String(payload?.url || ''))
    if (!['https:', 'http:'].includes(url.protocol) || !hostAllowed(url.hostname)) {
      throw new Error('Nem engedélyezett letöltési cím.')
    }

    const destDir = path.join(app.getPath('userData'), 'updates', 'download')
    await mkdir(destDir, { recursive: true })
    const dest = path.join(destDir, safeFileName(payload?.fileName || 'Odyssey Network update.zip'))
    await downloadUpdate(url.href, dest, (received, total) => {
      const percent = total > 0 ? Math.min(100, Math.round((received / total) * 100)) : 0
      event.sender.send('updater:progress', { received, total, percent })
    })
    return dest
  })

  ipcMain.handle('updater:install', async (_event, filePath) => {
    const resolved = path.resolve(String(filePath || ''))
    if (!existsSync(resolved)) {
      throw new Error('A letöltött fájl nem található.')
    }
    if (resolved.toLowerCase().endsWith('.zip')) {
      await installZipUpdate(resolved)
      return
    }
    if (!resolved.toLowerCase().endsWith('.exe')) {
      throw new Error('Ismeretlen frissítőfájl. 25 MB alatti update.zip kell.')
    }
    spawn(resolved, [], { detached: true, stdio: 'ignore' }).unref()
    setTimeout(() => app.quit(), 250)
  })
}

async function createWindow() {
  const distDir = resolveDistDir()
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 960,
    minHeight: 640,
    backgroundColor: '#05070d',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.mjs'),
      contextIsolation: true,
      sandbox: true,
    },
  })

  win.webContents.setWindowOpenHandler(({ url }) => {
    void shell.openExternal(url)
    return { action: 'deny' }
  })

  const devUrl = process.env.ELECTRON_START_URL
  if (devUrl) {
    await win.loadURL(devUrl)
    return
  }

  if (!existsSync(path.join(distDir, 'index.html'))) {
    throw new Error('A dist mappa hiányzik. Előbb futtasd: npm run build')
  }

  const url = await startStaticServer(distDir)
  await win.loadURL(url)
}

registerUpdaterIpc()
app.whenReady().then(() => createWindow())
app.on('window-all-closed', () => app.quit())
